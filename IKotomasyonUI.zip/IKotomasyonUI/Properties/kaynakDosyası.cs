﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IKotomasyon.UI.Properties
{
    internal class kaynakDosyası
    {
    }
}
