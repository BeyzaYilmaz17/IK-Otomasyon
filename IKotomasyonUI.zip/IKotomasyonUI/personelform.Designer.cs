﻿namespace IKotomasyon.UI
{
    partial class personelform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.Dashboardlabel = new System.Windows.Forms.Label();
            this.menüicon = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.kullanıcılabel = new System.Windows.Forms.Label();
            this.raporpanel = new System.Windows.Forms.Panel();
            this.duyurulabel = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.izinpanel = new System.Windows.Forms.Panel();
            this.İzinlabel = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.maaspanel = new System.Windows.Forms.Panel();
            this.maaslabel = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menüicon)).BeginInit();
            this.panel1.SuspendLayout();
            this.raporpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.izinpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.maaspanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.Dashboardlabel);
            this.panel3.Controls.Add(this.menüicon);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(260, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(982, 100);
            this.panel3.TabIndex = 2;
            // 
            // Dashboardlabel
            // 
            this.Dashboardlabel.AutoSize = true;
            this.Dashboardlabel.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dashboardlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Dashboardlabel.Location = new System.Drawing.Point(123, 30);
            this.Dashboardlabel.Name = "Dashboardlabel";
            this.Dashboardlabel.Size = new System.Drawing.Size(145, 26);
            this.Dashboardlabel.TabIndex = 3;
            this.Dashboardlabel.Text = "Dashboard";
            // 
            // menüicon
            // 
            this.menüicon.Image = global:: IKotomasyon.UI.Properties.Resources.burger_menu;
            this.menüicon.Location = new System.Drawing.Point(21, 12);
            this.menüicon.Name = "menüicon";
            this.menüicon.Size = new System.Drawing.Size(96, 64);
            this.menüicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.menüicon.TabIndex = 0;
            this.menüicon.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.maaspanel);
            this.panel1.Controls.Add(this.kullanıcılabel);
            this.panel1.Controls.Add(this.raporpanel);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.izinpanel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(260, 813);
            this.panel1.TabIndex = 3;
            // 
            // kullanıcılabel
            // 
            this.kullanıcılabel.AutoSize = true;
            this.kullanıcılabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kullanıcılabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.kullanıcılabel.Location = new System.Drawing.Point(77, 103);
            this.kullanıcılabel.Name = "kullanıcılabel";
            this.kullanıcılabel.Size = new System.Drawing.Size(102, 23);
            this.kullanıcılabel.TabIndex = 12;
            this.kullanıcılabel.Text = "Personel";
            // 
            // raporpanel
            // 
            this.raporpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.raporpanel.Controls.Add(this.duyurulabel);
            this.raporpanel.Controls.Add(this.pictureBox4);
            this.raporpanel.Location = new System.Drawing.Point(0, 189);
            this.raporpanel.Name = "raporpanel";
            this.raporpanel.Size = new System.Drawing.Size(263, 87);
            this.raporpanel.TabIndex = 13;
            // 
            // duyurulabel
            // 
            this.duyurulabel.AutoSize = true;
            this.duyurulabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.duyurulabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.duyurulabel.Location = new System.Drawing.Point(110, 37);
            this.duyurulabel.Name = "duyurulabel";
            this.duyurulabel.Size = new System.Drawing.Size(79, 20);
            this.duyurulabel.TabIndex = 6;
            this.duyurulabel.Text = "Duyuru";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global:: IKoyomasyon.UI.Properties.Resources.megaphone;
            this.pictureBox4.Location = new System.Drawing.Point(3, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(92, 87);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global:: IKoyomasyon.UI.Properties.Resources.owner;
            this.pictureBox2.Location = new System.Drawing.Point(79, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 97);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // izinpanel
            // 
            this.izinpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.izinpanel.Controls.Add(this.İzinlabel);
            this.izinpanel.Controls.Add(this.pictureBox3);
            this.izinpanel.Location = new System.Drawing.Point(0, 283);
            this.izinpanel.Name = "izinpanel";
            this.izinpanel.Size = new System.Drawing.Size(263, 87);
            this.izinpanel.TabIndex = 11;
            // 
            // İzinlabel
            // 
            this.İzinlabel.AutoSize = true;
            this.İzinlabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.İzinlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.İzinlabel.Location = new System.Drawing.Point(110, 40);
            this.İzinlabel.Name = "İzinlabel";
            this.İzinlabel.Size = new System.Drawing.Size(47, 20);
            this.İzinlabel.TabIndex = 5;
            this.İzinlabel.Text = "İzin ";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global:: IKoyomasyon.UI.Properties.Resources.calendar;
            this.pictureBox3.Location = new System.Drawing.Point(3, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(92, 90);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // maaspanel
            // 
            this.maaspanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.maaspanel.Controls.Add(this.maaslabel);
            this.maaspanel.Controls.Add(this.pictureBox6);
            this.maaspanel.Location = new System.Drawing.Point(3, 377);
            this.maaspanel.Name = "maaspanel";
            this.maaspanel.Size = new System.Drawing.Size(263, 87);
            this.maaspanel.TabIndex = 15;
            // 
            // maaslabel
            // 
            this.maaslabel.AutoSize = true;
            this.maaslabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maaslabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.maaslabel.Location = new System.Drawing.Point(108, 33);
            this.maaslabel.Name = "maaslabel";
            this.maaslabel.Size = new System.Drawing.Size(56, 20);
            this.maaslabel.TabIndex = 6;
            this.maaslabel.Text = "Maaş";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global:: IKoyomasyon.UI.Properties.Resources.sack_dollar;
            this.pictureBox6.Location = new System.Drawing.Point(3, 0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(92, 87);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 2;
            this.pictureBox6.TabStop = false;
            // 
            // personelform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1242, 813);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "personelform";
            this.Text = "personelform";
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menüicon)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.raporpanel.ResumeLayout(false);
            this.raporpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.izinpanel.ResumeLayout(false);
            this.izinpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.maaspanel.ResumeLayout(false);
            this.maaspanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label Dashboardlabel;
        private System.Windows.Forms.PictureBox menüicon;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label kullanıcılabel;
        private System.Windows.Forms.Panel raporpanel;
        private System.Windows.Forms.Label duyurulabel;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel izinpanel;
        private System.Windows.Forms.Label İzinlabel;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel maaspanel;
        private System.Windows.Forms.Label maaslabel;
        private System.Windows.Forms.PictureBox pictureBox6;
    }
}