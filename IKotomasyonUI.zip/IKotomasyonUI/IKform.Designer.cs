﻿namespace IKotomasyon.UI
{
    partial class IKform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Dashboardlabel = new System.Windows.Forms.Label();
            this.personellabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.performanspanel = new System.Windows.Forms.Panel();
            this.kullanıcılabel = new System.Windows.Forms.Label();
            this.raporpanel = new System.Windows.Forms.Panel();
            this.personeleklepanel = new System.Windows.Forms.Panel();
            this.departmanpanel = new System.Windows.Forms.Panel();
            this.departmanlabel = new System.Windows.Forms.Label();
            this.izinpanel = new System.Windows.Forms.Panel();
            this.İzinlabel = new System.Windows.Forms.Label();
            this.duyurulabel = new System.Windows.Forms.Label();
            this.performanslabel = new System.Windows.Forms.Label();
            this.menüicon = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.maaslabel = new System.Windows.Forms.Label();
            this.maaspanel = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.performanspanel.SuspendLayout();
            this.raporpanel.SuspendLayout();
            this.personeleklepanel.SuspendLayout();
            this.departmanpanel.SuspendLayout();
            this.izinpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menüicon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.maaspanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(260, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(922, 100);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.Dashboardlabel);
            this.panel3.Controls.Add(this.menüicon);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(922, 100);
            this.panel3.TabIndex = 1;
            // 
            // Dashboardlabel
            // 
            this.Dashboardlabel.AutoSize = true;
            this.Dashboardlabel.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dashboardlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Dashboardlabel.Location = new System.Drawing.Point(120, 47);
            this.Dashboardlabel.Name = "Dashboardlabel";
            this.Dashboardlabel.Size = new System.Drawing.Size(145, 26);
            this.Dashboardlabel.TabIndex = 3;
            this.Dashboardlabel.Text = "Dashboard";
            // 
            // personellabel
            // 
            this.personellabel.AutoSize = true;
            this.personellabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.personellabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.personellabel.Location = new System.Drawing.Point(110, 34);
            this.personellabel.Name = "personellabel";
            this.personellabel.Size = new System.Drawing.Size(87, 20);
            this.personellabel.TabIndex = 3;
            this.personellabel.Text = "Personel";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.performanspanel);
            this.panel1.Controls.Add(this.kullanıcılabel);
            this.panel1.Controls.Add(this.raporpanel);
            this.panel1.Controls.Add(this.maaspanel);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.personeleklepanel);
            this.panel1.Controls.Add(this.departmanpanel);
            this.panel1.Controls.Add(this.izinpanel);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(260, 813);
            this.panel1.TabIndex = 0;
            // 
            // performanspanel
            // 
            this.performanspanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.performanspanel.Controls.Add(this.performanslabel);
            this.performanspanel.Controls.Add(this.pictureBox7);
            this.performanspanel.Location = new System.Drawing.Point(0, 654);
            this.performanspanel.Name = "performanspanel";
            this.performanspanel.Size = new System.Drawing.Size(263, 87);
            this.performanspanel.TabIndex = 15;
            // 
            // kullanıcılabel
            // 
            this.kullanıcılabel.AutoSize = true;
            this.kullanıcılabel.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kullanıcılabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.kullanıcılabel.Location = new System.Drawing.Point(31, 103);
            this.kullanıcılabel.Name = "kullanıcılabel";
            this.kullanıcılabel.Size = new System.Drawing.Size(187, 23);
            this.kullanıcılabel.TabIndex = 12;
            this.kullanıcılabel.Text = "İnsan Kaynakları";
            // 
            // raporpanel
            // 
            this.raporpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.raporpanel.Controls.Add(this.duyurulabel);
            this.raporpanel.Controls.Add(this.pictureBox4);
            this.raporpanel.Location = new System.Drawing.Point(0, 189);
            this.raporpanel.Name = "raporpanel";
            this.raporpanel.Size = new System.Drawing.Size(263, 87);
            this.raporpanel.TabIndex = 13;
            // 
            // personeleklepanel
            // 
            this.personeleklepanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.personeleklepanel.Controls.Add(this.personellabel);
            this.personeleklepanel.Controls.Add(this.pictureBox8);
            this.personeleklepanel.Location = new System.Drawing.Point(0, 282);
            this.personeleklepanel.Name = "personeleklepanel";
            this.personeleklepanel.Size = new System.Drawing.Size(263, 87);
            this.personeleklepanel.TabIndex = 10;
            // 
            // departmanpanel
            // 
            this.departmanpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.departmanpanel.Controls.Add(this.departmanlabel);
            this.departmanpanel.Controls.Add(this.pictureBox5);
            this.departmanpanel.Location = new System.Drawing.Point(3, 375);
            this.departmanpanel.Name = "departmanpanel";
            this.departmanpanel.Size = new System.Drawing.Size(263, 87);
            this.departmanpanel.TabIndex = 12;
            // 
            // departmanlabel
            // 
            this.departmanlabel.AutoSize = true;
            this.departmanlabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.departmanlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.departmanlabel.Location = new System.Drawing.Point(110, 36);
            this.departmanlabel.Name = "departmanlabel";
            this.departmanlabel.Size = new System.Drawing.Size(113, 20);
            this.departmanlabel.TabIndex = 4;
            this.departmanlabel.Text = "Departman";
            // 
            // izinpanel
            // 
            this.izinpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.izinpanel.Controls.Add(this.İzinlabel);
            this.izinpanel.Controls.Add(this.pictureBox3);
            this.izinpanel.Location = new System.Drawing.Point(0, 468);
            this.izinpanel.Name = "izinpanel";
            this.izinpanel.Size = new System.Drawing.Size(263, 87);
            this.izinpanel.TabIndex = 11;
            // 
            // İzinlabel
            // 
            this.İzinlabel.AutoSize = true;
            this.İzinlabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.İzinlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.İzinlabel.Location = new System.Drawing.Point(110, 40);
            this.İzinlabel.Name = "İzinlabel";
            this.İzinlabel.Size = new System.Drawing.Size(47, 20);
            this.İzinlabel.TabIndex = 5;
            this.İzinlabel.Text = "İzin ";
            // 
            // duyurulabel
            // 
            this.duyurulabel.AutoSize = true;
            this.duyurulabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.duyurulabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.duyurulabel.Location = new System.Drawing.Point(110, 37);
            this.duyurulabel.Name = "duyurulabel";
            this.duyurulabel.Size = new System.Drawing.Size(79, 20);
            this.duyurulabel.TabIndex = 6;
            this.duyurulabel.Text = "Duyuru";
            // 
            // performanslabel
            // 
            this.performanslabel.AutoSize = true;
            this.performanslabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.performanslabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.performanslabel.Location = new System.Drawing.Point(103, 33);
            this.performanslabel.Name = "performanslabel";
            this.performanslabel.Size = new System.Drawing.Size(115, 20);
            this.performanslabel.TabIndex = 7;
            this.performanslabel.Text = "Performans";
            // 
            // menüicon
            // 
            this.menüicon.Image = global::IKotomasyon.UI.Properties.Resources.burger_menu;
            this.menüicon.Location = new System.Drawing.Point(18, 21);
            this.menüicon.Name = "menüicon";
            this.menüicon.Size = new System.Drawing.Size(96, 64);
            this.menüicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.menüicon.TabIndex = 0;
            this.menüicon.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::IKotomasyon.UI.Properties.Resources.star;
            this.pictureBox7.Location = new System.Drawing.Point(3, 3);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(92, 87);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 2;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::IKotomasyon.UI.Properties.Resources.megaphone;
            this.pictureBox4.Location = new System.Drawing.Point(3, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(92, 87);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::IKotomasyon.UI.Properties.Resources.owner;
            this.pictureBox2.Location = new System.Drawing.Point(79, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 97);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::IKotomasyon.UI.Properties.Resources.user_add;
            this.pictureBox8.Location = new System.Drawing.Point(3, 0);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(92, 87);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 1;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::IKotomasyon.UI.Properties.Resources.house_building;
            this.pictureBox5.Location = new System.Drawing.Point(3, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(92, 87);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::IKotomasyon.UI.Properties.Resources.calendar;
            this.pictureBox3.Location = new System.Drawing.Point(3, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(92, 90);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::IKotomasyon.UI.Properties.Resources.sack_dollar;
            this.pictureBox6.Location = new System.Drawing.Point(3, 0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(92, 87);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 2;
            this.pictureBox6.TabStop = false;
            // 
            // maaslabel
            // 
            this.maaslabel.AutoSize = true;
            this.maaslabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maaslabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.maaslabel.Location = new System.Drawing.Point(108, 33);
            this.maaslabel.Name = "maaslabel";
            this.maaslabel.Size = new System.Drawing.Size(50, 20);
            this.maaslabel.TabIndex = 6;
            this.maaslabel.Text = "Maaş";
            // 
            // maaspanel
            // 
            this.maaspanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.maaspanel.Controls.Add(this.maaslabel);
            this.maaspanel.Controls.Add(this.pictureBox6);
            this.maaspanel.Location = new System.Drawing.Point(0, 561);
            this.maaspanel.Name = "maaspanel";
            this.maaspanel.Size = new System.Drawing.Size(263, 87);
            this.maaspanel.TabIndex = 14;
            // 
            // IKform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 813);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "IKform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IKform";
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.performanspanel.ResumeLayout(false);
            this.performanspanel.PerformLayout();
            this.raporpanel.ResumeLayout(false);
            this.raporpanel.PerformLayout();
            this.personeleklepanel.ResumeLayout(false);
            this.personeleklepanel.PerformLayout();
            this.departmanpanel.ResumeLayout(false);
            this.departmanpanel.PerformLayout();
            this.izinpanel.ResumeLayout(false);
            this.izinpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menüicon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.maaspanel.ResumeLayout(false);
            this.maaspanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label personellabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label kullanıcılabel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label Dashboardlabel;
        private System.Windows.Forms.PictureBox menüicon;
        private System.Windows.Forms.Panel performanspanel;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Panel raporpanel;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel departmanpanel;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel izinpanel;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel personeleklepanel;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label departmanlabel;
        private System.Windows.Forms.Label İzinlabel;
        private System.Windows.Forms.Label duyurulabel;
        private System.Windows.Forms.Label performanslabel;
        private System.Windows.Forms.Panel maaspanel;
        private System.Windows.Forms.Label maaslabel;
        private System.Windows.Forms.PictureBox pictureBox6;
    }
}