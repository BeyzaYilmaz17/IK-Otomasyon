﻿namespace IKotomasyon.UI
{
    partial class Yoneticiform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Dashboardlabel = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.kullanıcılabel = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.performanspanel = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.maaspanel = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.raporpanel = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.departmanpanel = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.izinpanel = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.personeleklepanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menüicon = new System.Windows.Forms.PictureBox();
            this.İzinlabel = new System.Windows.Forms.Label();
            this.personellabel = new System.Windows.Forms.Label();
            this.departmanlabel = new System.Windows.Forms.Label();
            this.Raporlabel = new System.Windows.Forms.Label();
            this.maaslabel = new System.Windows.Forms.Label();
            this.performanslabel = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.performanspanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.maaspanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.raporpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.departmanpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.izinpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.personeleklepanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menüicon)).BeginInit();
            this.SuspendLayout();
            // 
            // Dashboardlabel
            // 
            this.Dashboardlabel.AutoSize = true;
            this.Dashboardlabel.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dashboardlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Dashboardlabel.Location = new System.Drawing.Point(120, 39);
            this.Dashboardlabel.Name = "Dashboardlabel";
            this.Dashboardlabel.Size = new System.Drawing.Size(145, 26);
            this.Dashboardlabel.TabIndex = 3;
            this.Dashboardlabel.Text = "Dashboard";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.kullanıcılabel);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.performanspanel);
            this.panel2.Controls.Add(this.maaspanel);
            this.panel2.Controls.Add(this.raporpanel);
            this.panel2.Controls.Add(this.departmanpanel);
            this.panel2.Controls.Add(this.izinpanel);
            this.panel2.Controls.Add(this.personeleklepanel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(260, 813);
            this.panel2.TabIndex = 1;
            // 
            // kullanıcılabel
            // 
            this.kullanıcılabel.AutoSize = true;
            this.kullanıcılabel.Font = new System.Drawing.Font("Lucida Fax", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kullanıcılabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.kullanıcılabel.Location = new System.Drawing.Point(71, 103);
            this.kullanıcılabel.Name = "kullanıcılabel";
            this.kullanıcılabel.Size = new System.Drawing.Size(111, 26);
            this.kullanıcılabel.TabIndex = 10;
            this.kullanıcılabel.Text = "Yönetici";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::IKotomasyon.UI.Properties.Resources.owner;
            this.pictureBox2.Location = new System.Drawing.Point(72, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(110, 97);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // performanspanel
            // 
            this.performanspanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.performanspanel.Controls.Add(this.performanslabel);
            this.performanspanel.Controls.Add(this.pictureBox7);
            this.performanspanel.Location = new System.Drawing.Point(0, 666);
            this.performanspanel.Name = "performanspanel";
            this.performanspanel.Size = new System.Drawing.Size(260, 87);
            this.performanspanel.TabIndex = 9;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::IKotomasyon.UI.Properties.Resources.star;
            this.pictureBox7.Location = new System.Drawing.Point(3, 3);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(92, 87);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 2;
            this.pictureBox7.TabStop = false;
            // 
            // maaspanel
            // 
            this.maaspanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.maaspanel.Controls.Add(this.maaslabel);
            this.maaspanel.Controls.Add(this.pictureBox6);
            this.maaspanel.Location = new System.Drawing.Point(0, 573);
            this.maaspanel.Name = "maaspanel";
            this.maaspanel.Size = new System.Drawing.Size(263, 87);
            this.maaspanel.TabIndex = 8;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::IKotomasyon.UI.Properties.Resources.sack_dollar;
            this.pictureBox6.Location = new System.Drawing.Point(3, 0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(92, 87);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 2;
            this.pictureBox6.TabStop = false;
            // 
            // raporpanel
            // 
            this.raporpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.raporpanel.Controls.Add(this.Raporlabel);
            this.raporpanel.Controls.Add(this.pictureBox4);
            this.raporpanel.Location = new System.Drawing.Point(0, 480);
            this.raporpanel.Name = "raporpanel";
            this.raporpanel.Size = new System.Drawing.Size(263, 87);
            this.raporpanel.TabIndex = 7;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::IKotomasyon.UI.Properties.Resources.stats;
            this.pictureBox4.Location = new System.Drawing.Point(3, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(92, 87);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // departmanpanel
            // 
            this.departmanpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.departmanpanel.Controls.Add(this.departmanlabel);
            this.departmanpanel.Controls.Add(this.pictureBox5);
            this.departmanpanel.Location = new System.Drawing.Point(0, 294);
            this.departmanpanel.Name = "departmanpanel";
            this.departmanpanel.Size = new System.Drawing.Size(260, 87);
            this.departmanpanel.TabIndex = 6;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::IKotomasyon.UI.Properties.Resources.house_building;
            this.pictureBox5.Location = new System.Drawing.Point(3, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(92, 87);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // izinpanel
            // 
            this.izinpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.izinpanel.Controls.Add(this.İzinlabel);
            this.izinpanel.Controls.Add(this.pictureBox3);
            this.izinpanel.Location = new System.Drawing.Point(0, 387);
            this.izinpanel.Name = "izinpanel";
            this.izinpanel.Size = new System.Drawing.Size(260, 87);
            this.izinpanel.TabIndex = 5;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::IKotomasyon.UI.Properties.Resources.calendar;
            this.pictureBox3.Location = new System.Drawing.Point(3, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(92, 90);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // personeleklepanel
            // 
            this.personeleklepanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(100)))));
            this.personeleklepanel.Controls.Add(this.personellabel);
            this.personeleklepanel.Controls.Add(this.pictureBox1);
            this.personeleklepanel.Location = new System.Drawing.Point(0, 201);
            this.personeleklepanel.Name = "personeleklepanel";
            this.personeleklepanel.Size = new System.Drawing.Size(263, 87);
            this.personeleklepanel.TabIndex = 4;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::IKotomasyon.UI.Properties.Resources.user_add;
            this.pictureBox1.Location = new System.Drawing.Point(3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(92, 87);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.Dashboardlabel);
            this.panel1.Controls.Add(this.menüicon);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(260, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(982, 100);
            this.panel1.TabIndex = 0;
            // 
            // menüicon
            // 
            this.menüicon.Image = global::IKotomasyon.UI.Properties.Resources.burger_menu;
            this.menüicon.Location = new System.Drawing.Point(18, 21);
            this.menüicon.Name = "menüicon";
            this.menüicon.Size = new System.Drawing.Size(96, 64);
            this.menüicon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.menüicon.TabIndex = 0;
            this.menüicon.TabStop = false;
            // 
            // İzinlabel
            // 
            this.İzinlabel.AutoSize = true;
            this.İzinlabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.İzinlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.İzinlabel.Location = new System.Drawing.Point(117, 36);
            this.İzinlabel.Name = "İzinlabel";
            this.İzinlabel.Size = new System.Drawing.Size(47, 20);
            this.İzinlabel.TabIndex = 6;
            this.İzinlabel.Text = "İzin ";
            // 
            // personellabel
            // 
            this.personellabel.AutoSize = true;
            this.personellabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.personellabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.personellabel.Location = new System.Drawing.Point(117, 37);
            this.personellabel.Name = "personellabel";
            this.personellabel.Size = new System.Drawing.Size(87, 20);
            this.personellabel.TabIndex = 4;
            this.personellabel.Text = "Personel";
            // 
            // departmanlabel
            // 
            this.departmanlabel.AutoSize = true;
            this.departmanlabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.departmanlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.departmanlabel.Location = new System.Drawing.Point(117, 35);
            this.departmanlabel.Name = "departmanlabel";
            this.departmanlabel.Size = new System.Drawing.Size(113, 20);
            this.departmanlabel.TabIndex = 5;
            this.departmanlabel.Text = "Departman";
            // 
            // Raporlabel
            // 
            this.Raporlabel.AutoSize = true;
            this.Raporlabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Raporlabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Raporlabel.Location = new System.Drawing.Point(117, 36);
            this.Raporlabel.Name = "Raporlabel";
            this.Raporlabel.Size = new System.Drawing.Size(65, 20);
            this.Raporlabel.TabIndex = 7;
            this.Raporlabel.Text = "Rapor";
            // 
            // maaslabel
            // 
            this.maaslabel.AutoSize = true;
            this.maaslabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maaslabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.maaslabel.Location = new System.Drawing.Point(117, 38);
            this.maaslabel.Name = "maaslabel";
            this.maaslabel.Size = new System.Drawing.Size(56, 20);
            this.maaslabel.TabIndex = 7;
            this.maaslabel.Text = "Maaş";
            // 
            // performanslabel
            // 
            this.performanslabel.AutoSize = true;
            this.performanslabel.Font = new System.Drawing.Font("Lucida Bright", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.performanslabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.performanslabel.Location = new System.Drawing.Point(117, 34);
            this.performanslabel.Name = "performanslabel";
            this.performanslabel.Size = new System.Drawing.Size(115, 20);
            this.performanslabel.TabIndex = 7;
            this.performanslabel.Text = "Performans";
            // 
            // Yoneticiform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1242, 813);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "Yoneticiform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Yoneticiform";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.performanspanel.ResumeLayout(false);
            this.performanspanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.maaspanel.ResumeLayout(false);
            this.maaspanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.raporpanel.ResumeLayout(false);
            this.raporpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.departmanpanel.ResumeLayout(false);
            this.departmanpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.izinpanel.ResumeLayout(false);
            this.izinpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.personeleklepanel.ResumeLayout(false);
            this.personeleklepanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menüicon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label Dashboardlabel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel personeleklepanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox menüicon;
        private System.Windows.Forms.Panel performanspanel;
        private System.Windows.Forms.Panel maaspanel;
        private System.Windows.Forms.Panel raporpanel;
        private System.Windows.Forms.Panel departmanpanel;
        private System.Windows.Forms.Panel izinpanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label kullanıcılabel;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label İzinlabel;
        private System.Windows.Forms.Label personellabel;
        private System.Windows.Forms.Label departmanlabel;
        private System.Windows.Forms.Label Raporlabel;
        private System.Windows.Forms.Label maaslabel;
        private System.Windows.Forms.Label performanslabel;
    }
}