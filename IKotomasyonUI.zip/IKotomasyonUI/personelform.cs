﻿using IKotomasyon.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IKotomasyon.UI
{
    public partial class personelform : Form
    {
        private Kullanici _kullanici;

        public personelform(Kullanici kullanici)
        {
            InitializeComponent();
            _kullanici = kullanici;
        }
    }
}
