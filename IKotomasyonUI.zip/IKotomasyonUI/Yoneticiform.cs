﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IKotomasyon.Entities;

namespace IKotomasyon.UI
{
    public partial class Yoneticiform : Form
    {
        private readonly Kullanici _kullanici;
        public Yoneticiform(Kullanici kullanici)
        {
            InitializeComponent();
            _kullanici = kullanici;
        }
    }

}

