﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IKotomasyon.Entities
{
    public class Kullanici
    {
        public int ID { get; set; }
        public string Kullanici_adi { get; set; }
        public string Sifre { get; set; }
        public string Rol { get; set; }
    }
}
